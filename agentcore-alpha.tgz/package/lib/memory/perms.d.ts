/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
export declare namespace MemoryPerms {
    /******************************************************************************
     *                          Data Plane Permissions
     *****************************************************************************/
    /**
     * Permissions for Short-Term Memory (STM)
     */
    namespace STM {
        /**
         * Permissions to write Short-Term Memory (STM)
         */
        const WRITE_PERMS: string[];
        /**
         * Permissions to read Short-Term Memory (STM)
         */
        const READ_PERMS: string[];
        /**
         * Permissions to delete Short-Term Memory (STM)
         */
        const DELETE_PERMS: string[];
    }
    /**
     * Permissions for Long-Term Memory (LTM)
     */
    namespace LTM {
        /**
         * Permissions to read Long-Term Memory (LTM)
         */
        const READ_PERMS: string[];
        /**
         * Permissions to delete Long-Term Memory (LTM)
         */
        const DELETE_PERMS: string[];
    }
    /**
     * Permissions to read both Short-Term Memory (STM) and Long-Term Memory (LTM)
     */
    const READ_PERMS: string[];
    /**
     * Permissions to delete both Short-Term Memory (STM) and Long-Term Memory (LTM)
     */
    const DELETE_PERMS: string[];
    /******************************************************************************
     *                         Control Plane Permissions
     *****************************************************************************/
    /**
     * Grants control plane operations to manage the memory (CRUD)
     */
    const ADMIN_PERMS: string[];
    const FULL_ACCESS_PERMS: string[];
}
