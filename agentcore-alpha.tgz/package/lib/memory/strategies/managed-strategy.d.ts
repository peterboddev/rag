/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IBedrockInvokable } from '@aws-cdk/aws-bedrock-alpha';
import type * as bedrockagentcore from 'aws-cdk-lib/aws-bedrockagentcore';
import type { Grant, IGrantable } from 'aws-cdk-lib/aws-iam';
import type { MemoryStrategyCommonProps, IMemoryStrategy } from '../memory-strategy';
import { MemoryStrategyType } from '../memory-strategy';
/**
 * Configuration for overriding model and prompt template
 */
export interface OverrideConfig {
    /**
     * The model to use for consolidation/extraction
     */
    readonly model: IBedrockInvokable;
    /**
     * The prompt that will be appended to the system prompt to define
     * the model's memory consolidation/extraction strategy.
     * This configuration provides customization to how the model identifies and extracts
     * relevant information for memory storage. You can use the default user prompt or create a customized one.
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/system-prompts.html
     */
    readonly appendToPrompt: string;
}
/**
 * Configuration for episodic memory reflection
 */
export interface EpisodicReflectionConfiguration {
    /**
     * Namespaces for episodic reflection
     * Minimum 1 namespace required
     */
    readonly namespaces: string[];
}
/**
 * Configuration parameters for a memory strategy that can override
 * existing built-in default prompts/models
 */
export interface ManagedStrategyProps extends MemoryStrategyCommonProps {
    /**
     * The configuration for the custom extraction.
     * This configuration provides customization to how the model identifies
     * and extracts relevant information for memory storage.
     * @default - No custom extraction
     */
    readonly customExtraction?: OverrideConfig;
    /**
     * The configuration for the custom consolidation.
     * This configuration provides customization to how the model identifies
     * and extracts relevant information for memory storage.
     * @default - No custom extraction
     */
    readonly customConsolidation?: OverrideConfig;
    /**
     * The namespaces for the strategy
     * Represents a namespace for organizing memory data
     * Use a hierarchical format separated by forward slashes (/)
     *
     * Use a hierarchical format separated by forward slashes (/) to organize namespaces logically.
     * You can include these defined variables:
     *
     * - {sessionId} - the user identifier to be created in the CreateEvent API
     * - {memoryStrategyId} - an identifier for an extraction strategy
     * - {sessionId} - an identifier for each session
     *
     * Example namespace path:
     * /strategies/{memoryStrategyId}/actions/{actionId}/sessions/{sessionId}
     *
     * After memory creation, this namespace might look like:
     * /actor/actor-3afc5aa8fef9/strategy/summarization-fy5c5fwc7/session/session-qj7tpd1kvr8
     */
    readonly namespaces: string[];
    /**
     * Configuration for episodic memory reflection (only applicable for EPISODIC strategy type)
     * Defines additional namespaces for reflection-based episodic recall
     * @default - No reflection configuration
     */
    readonly reflectionConfiguration?: EpisodicReflectionConfiguration;
}
/**
 * Managed memory strategy that handles both built-in and override configurations.
 * This strategy can be used for quick setup with built-in defaults or customized
 * with specific models and prompt templates.
 */
export declare class ManagedMemoryStrategy implements IMemoryStrategy {
    readonly name: string;
    readonly description?: string;
    /**
     * The namespaces for the strategy
     */
    readonly namespaces: string[];
    /**
     * The configuration for the custom consolidation.
     */
    readonly consolidationOverride?: OverrideConfig;
    /**
     * The configuration for the custom extraction.
     */
    readonly extractionOverride?: OverrideConfig;
    /**
     * The configuration for episodic reflection.
     */
    readonly reflectionConfiguration?: EpisodicReflectionConfiguration;
    readonly strategyType: MemoryStrategyType;
    /**
     * Constructor to create a new managed memory strategy
     * @param strategyType the strategy type
     * @param props the properties for the strategy
     */
    constructor(strategyType: MemoryStrategyType, props: ManagedStrategyProps);
    /**
     * Renders the network configuration as a CloudFormation property.
     * @returns The CloudFormation property for the memory strategy.
     */
    render(): bedrockagentcore.CfnMemory.MemoryStrategyProperty;
    /**
     * Grants the necessary permissions to the role
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The grantee to grant permissions to
     * @returns The Grant object for chaining
     */
    grant(grantee: IGrantable): Grant | undefined;
    /**
     * Validates the memory strategy name
     * @param name - The name to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyName;
    /**
     * Validates the prompt
     * @param prompt - The prompt to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validatePrompt;
    /**
     * Validates the memory strategy namespaces
     * @param namespaces - The namespaces to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyNamespaces;
    /**
     * Validates the episodic reflection configuration
     * @param config - The reflection configuration to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateReflectionConfiguration;
}
