/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
/******************************************************************************
 *                               EVALUATOR
 *****************************************************************************/
/**
 * Permissions for reading evaluator information
 */
export declare const EVALUATOR_READ_PERMS: string[];
/**
 * Permissions for listing evaluators
 */
export declare const EVALUATOR_LIST_PERMS: string[];
/**
 * Permissions for managing evaluators (update and delete)
 */
export declare const EVALUATOR_MANAGE_PERMS: string[];
/**
 * Permissions for invoking an evaluator
 */
export declare const EVALUATOR_INVOKE_PERMS: string[];
/******************************************************************************
 *                        ONLINE EVALUATION CONFIG
 *****************************************************************************/
/**
 * Permissions for reading online evaluation configuration information
 */
export declare const ONLINE_EVAL_CONFIG_READ_PERMS: string[];
/**
 * Permissions for listing online evaluation configurations
 */
export declare const ONLINE_EVAL_CONFIG_LIST_PERMS: string[];
/**
 * Permissions for managing online evaluation configurations (update and delete)
 */
export declare const ONLINE_EVAL_CONFIG_MANAGE_PERMS: string[];
