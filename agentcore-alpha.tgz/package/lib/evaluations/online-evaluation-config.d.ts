/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IResource, ResourceProps } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IEvaluator } from './evaluator';
/******************************************************************************
 *                                Enums
 *****************************************************************************/
/**
 * The execution status of an online evaluation configuration.
 */
export declare enum ExecutionStatus {
    /** The online evaluation configuration is actively processing traces. */
    ENABLED = "ENABLED",
    /** The online evaluation configuration is paused. */
    DISABLED = "DISABLED"
}
/******************************************************************************
 *                          Data Source Config
 *****************************************************************************/
/**
 * Properties for creating a CloudWatch Logs data source configuration.
 */
export interface CloudWatchLogsDataSourceProps {
    /**
     * The CloudWatch log group names to monitor.
     */
    readonly logGroupNames: string[];
    /**
     * The service names associated with the log groups.
     */
    readonly serviceNames: string[];
}
/**
 * Configuration for the data source used by an online evaluation.
 *
 * Use the static factory methods to create a data source configuration.
 * Currently supports CloudWatch Logs as a data source.
 */
export declare class DataSourceConfig {
    /**
     * Creates a CloudWatch Logs data source configuration.
     *
     * @param props - The CloudWatch Logs data source properties
     * @returns A DataSourceConfig configured for CloudWatch Logs
     */
    static fromCloudWatchLogs(props: CloudWatchLogsDataSourceProps): DataSourceConfig;
    /**
     * The CloudWatch log group names configured for this data source.
     */
    readonly logGroupNames: string[];
    private readonly config;
    private constructor();
    /**
     * Renders the data source configuration to the L1 CloudFormation shape.
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                            Filter Value
 *****************************************************************************/
/**
 * Represents a filter value for online evaluation filter conditions.
 *
 * Use the static factory methods to create a filter value from a string,
 * number, or boolean. This avoids jsii-incompatible union types.
 */
export declare class FilterValue {
    /**
     * Creates a filter value from a string.
     *
     * @param value - The string value
     * @returns A FilterValue wrapping the string
     */
    static fromString(value: string): FilterValue;
    /**
     * Creates a filter value from a number.
     *
     * @param value - The numeric value
     * @returns A FilterValue wrapping the number
     */
    static fromNumber(value: number): FilterValue;
    /**
     * Creates a filter value from a boolean.
     *
     * @param value - The boolean value
     * @returns A FilterValue wrapping the boolean
     */
    static fromBoolean(value: boolean): FilterValue;
    private readonly config;
    private constructor();
    /**
     * Renders the filter value to the L1 CloudFormation shape.
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                          Filter Condition
 *****************************************************************************/
/**
 * A filter condition for selecting which sessions to evaluate.
 */
export interface FilterCondition {
    /**
     * The key to filter on.
     */
    readonly key: string;
    /**
     * The comparison operator (e.g., "EQUALS", "NOT_EQUALS").
     */
    readonly operator: string;
    /**
     * The value to compare against.
     */
    readonly value: FilterValue;
}
/******************************************************************************
 *                        Evaluator Reference
 *****************************************************************************/
/**
 * A reference to an evaluator for use in an online evaluation configuration.
 *
 * Supports both built-in evaluator IDs (e.g., "Builtin.Helpfulness") and
 * custom Evaluator construct instances. Use the static factory methods to
 * create a reference.
 */
export declare class EvaluatorReference {
    /**
     * Creates a reference to a built-in evaluator by its ID.
     *
     * @param evaluatorId - The built-in evaluator ID (e.g., "Builtin.Helpfulness")
     * @returns An EvaluatorReference for the built-in evaluator
     */
    static fromBuiltIn(evaluatorId: string): EvaluatorReference;
    /**
     * Creates a reference to a custom Evaluator construct.
     *
     * @param evaluator - The Evaluator construct instance
     * @returns An EvaluatorReference for the custom evaluator
     */
    static fromEvaluator(evaluator: IEvaluator): EvaluatorReference;
    private readonly config;
    private constructor();
    /**
     * Renders the evaluator reference to the evaluator ID string.
     * @internal
     */
    _render(): string;
    /**
     * Returns whether this reference points to a custom evaluator.
     * @internal
     */
    _isCustom(): boolean;
    /**
     * Returns the ARN of the custom evaluator, or undefined for built-in evaluators.
     * @internal
     */
    _getArn(): string | undefined;
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for OnlineEvaluationConfig resources.
 */
export interface IOnlineEvaluationConfig extends IResource, iam.IGrantable {
    /**
     * The ARN of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigArn: string;
    /**
     * The ID of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigId: string;
    /**
     * Grants IAM actions to the IAM Principal.
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the OnlineEvaluationConfig.
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Update`, `Delete`, and read actions on the OnlineEvaluationConfig.
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an OnlineEvaluationConfig.
 * Contains methods and attributes valid for OnlineEvaluationConfigs either created with CDK or imported.
 */
export declare abstract class OnlineEvaluationConfigBase extends Resource implements IOnlineEvaluationConfig {
    abstract readonly onlineEvaluationConfigArn: string;
    abstract readonly onlineEvaluationConfigId: string;
    /**
     * The principal to grant permissions to.
     */
    abstract readonly grantPrincipal: iam.IPrincipal;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * Grants IAM actions to the IAM Principal.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @param actions - The actions to grant
     * @returns An IAM Grant object representing the granted permissions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions on this online evaluation config to an IAM principal.
     * This includes both read permissions on the specific config and list permissions on all configs.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant read permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant manage permissions on this online evaluation config to an IAM principal.
     * This includes update, delete, and read permissions.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant manage permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating an OnlineEvaluationConfig resource.
 */
export interface OnlineEvaluationConfigProps {
    /**
     * The name of the online evaluation configuration.
     * Valid characters are a-z, A-Z, 0-9, _ (underscore).
     * The name must start with a letter and can be up to 48 characters long.
     * Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}
     *
     * @default - auto-generated
     */
    readonly onlineEvaluationConfigName?: string;
    /**
     * The data source configuration for the online evaluation.
     */
    readonly dataSourceConfig: DataSourceConfig;
    /**
     * The list of evaluator references to use for evaluation.
     * Supports both built-in evaluator IDs and custom Evaluator construct instances.
     * Maximum of 10 evaluator references allowed.
     */
    readonly evaluators: EvaluatorReference[];
    /**
     * The percentage of agent sessions to evaluate (0.01 to 100).
     */
    readonly samplingPercentage: number;
    /**
     * Optional description for the online evaluation configuration.
     *
     * @default - No description
     */
    readonly description?: string;
    /**
     * Tags to apply to this online evaluation configuration resource.
     *
     * @default - No tags
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * The IAM role that provides permissions for the evaluation service.
     * If not provided, a new role will be created with the necessary permissions.
     *
     * @default - A new role is created
     */
    readonly executionRole?: iam.IRole;
    /**
     * The execution status of the online evaluation configuration.
     *
     * @default ExecutionStatus.DISABLED
     */
    readonly executionStatus?: ExecutionStatus;
    /**
     * Optional filter conditions to select which sessions to evaluate.
     *
     * @default - No filters
     */
    readonly filters?: FilterCondition[];
    /**
     * Optional session timeout in minutes.
     *
     * @default - No session timeout
     */
    readonly sessionTimeoutMinutes?: number;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes for specifying an imported OnlineEvaluationConfig.
 */
export interface OnlineEvaluationConfigAttributes {
    /**
     * The ARN of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigArn: string;
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * An OnlineEvaluationConfig resource for AWS Bedrock AgentCore.
 * Represents a continuous monitoring configuration that evaluates live agent
 * traffic from CloudWatch Logs using a set of evaluators.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/evaluations.html
 * @resource AWS::BedrockAgentCore::OnlineEvaluationConfig
 */
export declare class OnlineEvaluationConfig extends OnlineEvaluationConfigBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates an OnlineEvaluationConfig reference from an existing config's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing online evaluation configuration
     * @returns An IOnlineEvaluationConfig reference to the existing config
     */
    static fromOnlineEvaluationConfigAttributes(scope: Construct, id: string, attrs: OnlineEvaluationConfigAttributes): IOnlineEvaluationConfig;
    /**
     * The ARN of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigArn: string;
    /**
     * The ID of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigId: string;
    /**
     * The status of the online evaluation configuration.
     * @attribute
     */
    readonly status?: string;
    /**
     * The IAM role that provides permissions for the evaluation service.
     */
    readonly executionRole: iam.IRole;
    /**
     * The principal to grant permissions to.
     */
    readonly grantPrincipal: iam.IPrincipal;
    private readonly __resource;
    constructor(scope: Construct, id: string, props: OnlineEvaluationConfigProps);
    /**
     * Creates the execution role needed for the evaluation service to access AWS resources.
     * @returns The created role
     * @internal This is an internal core function and should not be called directly.
     */
    private _createExecutionRole;
}
