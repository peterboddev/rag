/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IResource, ResourceProps } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import type { Construct } from 'constructs';
/******************************************************************************
 *                                Enums
 *****************************************************************************/
/**
 * The granularity level at which evaluation occurs.
 */
export declare enum EvaluationLevel {
    /** Evaluate at the session level */
    SESSION = "SESSION",
    /** Evaluate at the trace level */
    TRACE = "TRACE",
    /** Evaluate at the tool call level */
    TOOL_CALL = "TOOL_CALL"
}
/******************************************************************************
 *                           Rating Scale
 *****************************************************************************/
/**
 * A categorical rating entry for an LLM-as-a-Judge evaluator.
 */
export interface CategoricalRatingEntry {
    /**
     * The label for this rating entry.
     */
    readonly label: string;
    /**
     * The definition describing what this rating label means.
     */
    readonly definition: string;
}
/**
 * A numerical rating entry for an LLM-as-a-Judge evaluator.
 */
export interface NumericalRatingEntry {
    /**
     * The label for this rating entry.
     */
    readonly label: string;
    /**
     * The definition describing what this rating label means.
     */
    readonly definition: string;
    /**
     * The numeric value associated with this rating entry.
     */
    readonly value: number;
}
/**
 * Defines the rating scale used by an LLM-as-a-Judge evaluator.
 *
 * Use the static factory methods to create either a categorical or numerical rating scale.
 * Categorical scales use label/definition pairs, while numerical scales add a numeric value.
 */
export declare class RatingScale {
    /**
     * Creates a categorical rating scale.
     *
     * @param entries - The categorical rating entries (label and definition pairs)
     * @returns A RatingScale configured with categorical entries
     */
    static categorical(entries: CategoricalRatingEntry[]): RatingScale;
    /**
     * Creates a numerical rating scale.
     *
     * @param entries - The numerical rating entries (label, definition, and numeric value)
     * @returns A RatingScale configured with numerical entries
     */
    static numerical(entries: NumericalRatingEntry[]): RatingScale;
    private readonly config;
    private constructor();
    /**
     * Renders the rating scale to the L1 CloudFormation shape.
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                         Evaluator Config
 *****************************************************************************/
/**
 * Properties for creating an LLM-as-a-Judge evaluator configuration.
 */
export interface LlmAsAJudgeProps {
    /**
     * The evaluation instructions containing placeholders for the LLM judge.
     */
    readonly evaluationInstructions: string;
    /**
     * The Bedrock model ID to use as the judge.
     */
    readonly modelId: string;
    /**
     * The rating scale for the evaluator.
     */
    readonly ratingScale: RatingScale;
    /**
     * The maximum number of tokens to generate.
     *
     * @default - No max tokens limit
     */
    readonly maxTokens?: number;
    /**
     * The temperature for model inference.
     *
     * @default - Model default temperature
     */
    readonly temperature?: number;
    /**
     * The topP value for model inference.
     *
     * @default - Model default topP
     */
    readonly topP?: number;
    /**
     * Additional model request fields as an untyped map.
     *
     * @default - No additional fields
     */
    readonly additionalModelRequestFields?: {
        [key: string]: any;
    };
}
/**
 * Properties for creating a code-based evaluator configuration.
 */
export interface CodeBasedProps {
    /**
     * The Lambda function to use for evaluation.
     */
    readonly lambdaFunction: lambda.IFunction;
    /**
     * The timeout in seconds for the Lambda function invocation.
     *
     * @default - No timeout (1-300 seconds)
     */
    readonly lambdaTimeoutInSeconds?: number;
}
/**
 * Configuration for an Evaluator resource.
 *
 * Use the static factory methods to create either an LLM-as-a-Judge or code-based configuration.
 */
export declare class EvaluatorConfig {
    /**
     * Creates an LLM-as-a-Judge evaluator configuration.
     *
     * @param props - The LLM-as-a-Judge configuration properties
     * @returns An EvaluatorConfig for LLM-as-a-Judge evaluation
     */
    static llmAsAJudge(props: LlmAsAJudgeProps): EvaluatorConfig;
    /**
     * Creates a code-based evaluator configuration.
     *
     * @param props - The code-based configuration properties
     * @returns An EvaluatorConfig for code-based evaluation
     */
    static codeBased(props: CodeBasedProps): EvaluatorConfig;
    private readonly config;
    private constructor();
    /**
     * Renders the evaluator configuration to the L1 CloudFormation shape.
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for Evaluator resources.
 */
export interface IEvaluator extends IResource, iam.IGrantable {
    /**
     * The ARN of the evaluator resource.
     * @attribute
     */
    readonly evaluatorArn: string;
    /**
     * The ID of the evaluator.
     * @attribute
     */
    readonly evaluatorId: string;
    /**
     * Grants IAM actions to the IAM Principal.
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Evaluator.
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Update`, `Delete`, and read actions on the Evaluator.
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an Evaluator.
 * Contains methods and attributes valid for Evaluators either created with CDK or imported.
 */
export declare abstract class EvaluatorBase extends Resource implements IEvaluator {
    abstract readonly evaluatorArn: string;
    abstract readonly evaluatorId: string;
    /**
     * The principal to grant permissions to.
     */
    abstract readonly grantPrincipal: iam.IPrincipal;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * Grants IAM actions to the IAM Principal.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @param actions - The actions to grant
     * @returns An IAM Grant object representing the granted permissions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions on this evaluator to an IAM principal.
     * This includes both read permissions on the specific evaluator and list permissions on all evaluators.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant read permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant manage permissions on this evaluator to an IAM principal.
     * This includes update, delete, and read permissions.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant manage permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating an Evaluator resource.
 */
export interface EvaluatorProps {
    /**
     * The name of the evaluator.
     * Valid characters are a-z, A-Z, 0-9, _ (underscore).
     * The name must start with a letter and can be up to 48 characters long.
     * Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}
     *
     * @default - auto-generated
     */
    readonly evaluatorName?: string;
    /**
     * The evaluator configuration (LLM-as-a-Judge or code-based).
     */
    readonly evaluatorConfig: EvaluatorConfig;
    /**
     * The evaluation level (SESSION, TRACE, or TOOL_CALL).
     */
    readonly level: EvaluationLevel;
    /**
     * Optional description for the evaluator.
     *
     * @default - No description
     */
    readonly description?: string;
    /**
     * Tags to apply to this evaluator resource.
     *
     * @default - No tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes for specifying an imported Evaluator.
 */
export interface EvaluatorAttributes {
    /**
     * The ARN of the evaluator.
     * @attribute
     */
    readonly evaluatorArn: string;
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * An Evaluator resource for AWS Bedrock AgentCore.
 * Represents a custom evaluator that assesses agent performance using either
 * LLM-as-a-Judge or code-based (Lambda) evaluation logic.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/evaluations.html
 * @resource AWS::BedrockAgentCore::Evaluator
 */
export declare class Evaluator extends EvaluatorBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates an Evaluator reference from an existing evaluator's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing evaluator
     * @returns An IEvaluator reference to the existing evaluator
     */
    static fromEvaluatorAttributes(scope: Construct, id: string, attrs: EvaluatorAttributes): IEvaluator;
    /**
     * The ARN of the evaluator resource.
     * @attribute
     */
    readonly evaluatorArn: string;
    /**
     * The ID of the evaluator.
     * @attribute
     */
    readonly evaluatorId: string;
    /**
     * The status of the evaluator.
     * @attribute
     */
    readonly status?: string;
    /**
     * The principal to grant permissions to.
     */
    readonly grantPrincipal: iam.IPrincipal;
    private readonly __resource;
    constructor(scope: Construct, id: string, props: EvaluatorProps);
}
