/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
interface IntervalValidation {
    fieldName: string;
    minLength: number;
    maxLength: number;
}
interface StringLengthValidation extends IntervalValidation {
    value: string;
}
/**
 * Validates the length of a string field against minimum and maximum constraints.
 * @param params - Validation parameters including value, fieldName, minLength, and maxLength
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateStringFieldLength(params: StringLengthValidation): string[];
/**
 * Validates a string field against a regex pattern.
 * @param value - The string value to validate
 * @param fieldName - Name of the field being validated (for error messages)
 * @param pattern - Regular expression pattern to test against
 * @param customMessage - Optional custom error message
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateFieldPattern(value: string, fieldName: string, pattern: RegExp, customMessage?: string): string[];
export type ValidationFn<T> = (param: T) => string[];
export declare function throwIfInvalid<T>(validationFn: ValidationFn<T>, param: T): T;
/**
 * Validates that a sampling percentage is between 0.01 and 100 (inclusive).
 * @param value - The sampling percentage to validate
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateSamplingPercentage(value: number): string[];
/**
 * Validates that the number of evaluators does not exceed the maximum count.
 * @param evaluators - The array of evaluators to validate
 * @param maxCount - The maximum allowed number of evaluators
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateEvaluatorCount(evaluators: unknown[], maxCount: number): string[];
/**
 * Validates an evaluator name for length (1-48) and pattern ([a-zA-Z][a-zA-Z0-9_]*).
 * @param name - The evaluator name to validate
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateEvaluatorName(name: string): string[];
/**
 * Validates an online evaluation config name for length (1-48) and pattern ([a-zA-Z][a-zA-Z0-9_]*).
 * @param name - The online evaluation config name to validate
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateOnlineEvaluationConfigName(name: string): string[];
/**
 * Validates tags for key length (1-128) and value length (0-256).
 * @param tags - Optional map of tag key-value pairs to validate
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateTags(tags?: {
    [key: string]: string;
}): string[];
export {};
