/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IResource, ResourceProps } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { IRuntimeRef, RuntimeReference } from 'aws-cdk-lib/aws-bedrockagentcore';
import type { DimensionsMap, MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for Agent Runtime resources
 */
export interface IBedrockAgentRuntime extends IResource, iam.IGrantable, ec2.IConnectable, IRuntimeRef {
    /**
     * The ARN of the agent runtime resource
     * - Format `arn:${Partition}:bedrock-agentcore:${Region}:${Account}:runtime/${RuntimeId}`
     *
     * @attribute
     * @example "arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123"
     */
    readonly agentRuntimeArn: string;
    /**
     * The ID of the agent runtime
     * @attribute
     * @example "runtime-abc123"
     */
    readonly agentRuntimeId: string;
    /**
     * The name of the agent runtime
     */
    readonly agentRuntimeName: string;
    /**
     * The IAM role that provides permissions for the agent runtime
     *
     */
    readonly role: iam.IRole;
    /**
     * The version of the agent runtime
     * @attribute
     */
    readonly agentRuntimeVersion?: string;
    /**
     * The current status of the agent runtime
     */
    readonly agentStatus?: string;
    /**
     * The time at which the runtime was created
     * @attribute
     * @example "2024-01-15T10:30:00Z"
     */
    readonly createdAt?: string;
    /**
     * The time at which the runtime was last updated
     * @attribute
     * @example "2024-01-15T14:45:00Z"
     */
    readonly lastUpdatedAt?: string;
    /**
     * Return the given named metric for this agent runtime.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations for this agent runtime.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations across all resources.
     */
    metricInvocationsAggregated(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of throttled requests for this agent runtime.
     */
    metricThrottles(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of system errors for this agent runtime.
     */
    metricSystemErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of user errors for this agent runtime.
     */
    metricUserErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the latency of requests for this agent runtime.
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of errors (system + user) for this agent runtime.
     */
    metricTotalErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of agent sessions for this agent runtime.
     */
    metricSessionCount(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of sessions across all resources.
     */
    metricSessionsAggregated(props?: MetricOptions): Metric;
    /**
     * Grant the runtime specific actions on AWS resources
     *
     * @param actions The actions to grant
     * @param resources The resource ARNs to grant access to
     * @returns The Grant object for chaining
     */
    grant(actions: string[], resources: string[]): iam.Grant;
    /**
     * Adds a policy statement to the runtime's execution role
     *
     * @param statement The IAM policy statement to add
     * @returns The runtime instance for chaining
     */
    addToRolePolicy(statement: iam.PolicyStatement): IBedrockAgentRuntime;
    /**
     * Permits an IAM principal to invoke this runtime
     * Grants the bedrock-agentcore:InvokeAgentRuntime permission
     * @param grantee The principal to grant access to
     */
    grantInvokeRuntime(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal to invoke this runtime on behalf of a user
     * Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission
     * Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header
     * @param grantee The principal to grant access to
     */
    grantInvokeRuntimeForUser(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal to invoke this runtime both directly and on behalf of users
     * Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions
     * @param grantee The principal to grant access to
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                                Base Class
 *****************************************************************************/
/**
 * Base class for Agent Runtime
 */
export declare abstract class RuntimeBase extends Resource implements IBedrockAgentRuntime {
    abstract readonly agentRuntimeArn: string;
    abstract readonly agentRuntimeId: string;
    abstract readonly agentRuntimeName: string;
    abstract readonly role: iam.IRole;
    abstract readonly agentRuntimeVersion?: string;
    abstract readonly agentStatus?: string;
    abstract readonly createdAt?: string;
    abstract readonly lastUpdatedAt?: string;
    abstract readonly grantPrincipal: iam.IPrincipal;
    /**
     * A reference to a Runtime resource.
     */
    get runtimeRef(): RuntimeReference;
    /**
     * An accessor for the Connections object that will fail if this Runtime does not have a VPC
     * configured.
     */
    get connections(): ec2.Connections;
    /**
     * The actual Connections object for this Runtime. This may be unset in the event that a VPC has not
     * been configured.
     * @internal
     */
    protected _connections: ec2.Connections | undefined;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * Grant the runtime specific actions on AWS resources
     *
     * [disable-awslint:no-grants]
     *
     * @param actions The actions to grant
     * @param resources The resource ARNs to grant access to
     * @returns The Grant object for chaining
     */
    grant(actions: string[], resources: string[]): iam.Grant;
    /**
     * Adds a policy statement to the runtime's execution role
     *
     * @param statement The IAM policy statement to add
     * @returns The runtime instance for chaining
     */
    addToRolePolicy(statement: iam.PolicyStatement): IBedrockAgentRuntime;
    /**
     * Permits an IAM principal to invoke this runtime
     * Grants the bedrock-agentcore:InvokeAgentRuntime permission
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant access to
     */
    grantInvokeRuntime(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal to invoke this runtime on behalf of a user
     * Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission
     * Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant access to
     */
    grantInvokeRuntimeForUser(grantee: iam.IGrantable): iam.Grant;
    /**
     * Permits an IAM principal to invoke this runtime both directly and on behalf of users
     * Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant access to
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this agent runtime.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations for this agent runtime.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations across all resources.
     */
    metricInvocationsAggregated(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of throttled requests for this agent runtime.
     */
    metricThrottles(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of system errors for this agent runtime.
     */
    metricSystemErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of user errors for this agent runtime.
     */
    metricUserErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the latency of requests for this agent runtime.
     *
     * The latency metric represents the total time elapsed between receiving the request
     * and sending the final response token, representing complete end-to-end processing time.
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of errors (system + user) for this agent runtime.
     */
    metricTotalErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of agent sessions for this agent runtime.
     */
    metricSessionCount(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of sessions across all resources.
     */
    metricSessionsAggregated(props?: MetricOptions): Metric;
    /**
     * Internal method to create a metric.
     */
    private configureMetric;
}
/**
 * Attributes for importing an existing Agent Runtime
 */
export interface AgentRuntimeAttributes {
    /**
     * The ARN of the agent runtime
     */
    readonly agentRuntimeArn: string;
    /**
     * The ID of the agent runtime
     */
    readonly agentRuntimeId: string;
    /**
     * The name of the agent runtime
     */
    readonly agentRuntimeName: string;
    /**
     * The IAM role ARN
     */
    readonly roleArn: string;
    /**
     * The version of the agent runtime
     * When importing a runtime and this is not specified or undefined, endpoints created on this runtime
     * will point to version "1" unless explicitly overridden.
     * @default - undefined
     */
    readonly agentRuntimeVersion?: string;
    /**
     * The description of the agent runtime
     * @default - No description
     */
    readonly description?: string;
    /**
     * The security groups for this runtime, if in a VPC.
     * @default - By default, the runtime is not in a VPC.
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * The current status of the agent runtime
     * @default - Status not available
     */
    readonly agentStatus?: string;
    /**
     * The time at which the runtime was created
     * @default - Creation time not available
     */
    readonly createdAt?: string;
    /**
     * The time at which the runtime was last updated
     * @default - Last update time not available
     */
    readonly lastUpdatedAt?: string;
}
