import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { GatewayTargetReference, IGatewayTargetRef } from 'aws-cdk-lib/aws-bedrockagentcore';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { IGateway } from '../gateway-base';
import type { ICredentialProviderConfig } from '../outbound-auth/credential-provider';
/******************************************************************************
 *                                 ENUM
 *****************************************************************************/
/**
 * Protocol types supported by gateway targets
 */
export declare enum GatewayTargetProtocolType {
    /** Model Context Protocol type */
    MCP = "MCP"
}
/**
 * MCP target types
 */
export declare enum McpTargetType {
    /** OpenAPI schema target type */
    OPENAPI_SCHEMA = "OPENAPI_SCHEMA",
    /** Smithy model target type */
    SMITHY_MODEL = "SMITHY_MODEL",
    /** Lambda function target type */
    LAMBDA = "LAMBDA",
    /** MCP server target type */
    MCP_SERVER = "MCP_SERVER",
    /** API Gateway target type */
    API_GATEWAY = "API_GATEWAY"
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for GatewayTarget resources
 *
 * Represents a target that hosts tools for the gateway.
 * Targets can be Lambda functions, OpenAPI schemas, or Smithy models.
 */
export interface IGatewayTarget extends IResource, IGatewayTargetRef {
    /**
     * The ARN of the gateway target resource
     * @attribute
     */
    readonly targetArn: string;
    /**
     * The id of the gateway target
     * @attribute
     */
    readonly targetId: string;
    /**
     * The name of the gateway target
     */
    readonly name: string;
    /**
     * The description of the gateway target
     */
    readonly description?: string;
    /**
     * The gateway that this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The target protocol
     */
    readonly targetProtocolType: GatewayTargetProtocolType;
    /**
     * The credential provider configuration for the target
     */
    readonly credentialProviderConfigurations: ICredentialProviderConfig[] | undefined;
    /**
     * The status of the gateway target
     * @attribute
     */
    readonly status?: string;
    /**
     * The status reasons for the gateway target
     * @attribute
     */
    readonly statusReasons?: string[];
    /**
     * Timestamp when the gateway target was created
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * Timestamp when the gateway target was last updated
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway Target
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway Target
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Interface for MCP gateway targets
 *
 * Extends the base gateway target interface with MCP-specific properties.
 * MCP targets expose tools using the Model Context Protocol.
 */
export interface IMcpGatewayTarget extends IGatewayTarget {
    /**
     * The type of target (Lambda, OpenAPI, or Smithy)
     */
    readonly targetType: McpTargetType;
}
/******************************************************************************
 *                                Base Class
 *****************************************************************************/
/**
 * Base class for gateway target implementations
 *
 * Provides common functionality for all gateway target types including
 * permission management and property definitions.
 */
export declare abstract class GatewayTargetBase extends Resource implements IGatewayTarget {
    abstract readonly targetArn: string;
    abstract readonly targetId: string;
    abstract readonly name: string;
    abstract readonly description?: string;
    abstract readonly gateway: IGateway;
    abstract readonly credentialProviderConfigurations: ICredentialProviderConfig[] | undefined;
    abstract readonly status?: string;
    abstract readonly statusReasons?: string[];
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    abstract readonly targetProtocolType: GatewayTargetProtocolType;
    /**
     * A reference to a GatewayTarget resource.
     */
    get gatewayTargetRef(): GatewayTargetReference;
    /**
     * Grants IAM actions to the IAM Principal
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant permissions to
     * @param actions The IAM actions to grant
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway Target
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant read permissions to
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway Target
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal to grant manage permissions to
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
